<input type="hidden" class="msg_opps" value="<?php echo trans('oops'); ?>">
<input type="hidden" class="msg_error" value="<?php echo trans('error'); ?>">
<input type="hidden" class="msg_success" value="<?php echo trans('success'); ?>">
<input type="hidden" class="msg_sorry" value="<?php echo trans('sorry'); ?>">
<input type="hidden" class="msg_yes" value="<?php echo trans('yes'); ?>">
<input type="hidden" class="msg_congratulations" value="<?php echo trans('congratulations'); ?>">
<input type="hidden" class="msg_something_wrong" value="<?php echo trans('something-wrong'); ?>">
<input type="hidden" class="msg_try_again" value="<?php echo trans('try-again'); ?>">
<input type="hidden" class="msg_valid_user_msg" value="<?php echo trans('valid-user-msg'); ?>">
<input type="hidden" class="msg_password_reset_msg" value="<?php echo trans('password-reset-msg'); ?>">
<input type="hidden" class="msg_password_reset_success_msg" value="<?php echo trans('password-reset-success-msg'); ?>">
<input type="hidden" class="msg_confirm_pass_not_match_msg" value="<?php echo trans('confirm-pass-not-match-msg'); ?>">
<input type="hidden" class="msg_old_password_doesnt_match" value="<?php echo trans('old-password-doesnt-match'); ?>">
<input type="hidden" class="msg_inserted" value="<?php echo trans('msg-inserted'); ?>">
<input type="hidden" class="msg_made_changes_not_saved" value="<?php echo trans('made-changes-not-saved'); ?>">
<input type="hidden" class="msg_no_data_founds" value="<?php echo trans('no-data-founds'); ?>">
<input type="hidden" class="msg_del_success" value="<?php echo trans('deleted-successfully'); ?>">
<input type="hidden" class="msg_account_suspend_msg" value="<?php echo trans('account-suspend-msg'); ?>">
<input type="hidden" class="msg_are_you_sure" value="<?php echo trans('are-you-sure'); ?>">
<input type="hidden" class="msg_get_started" value="<?php echo trans('get-started'); ?>">
<input type="hidden" class="msg_not_recover_file" value="<?php echo trans('not-recover-file'); ?>">
<input type="hidden" class="msg_deleted_successfully" value="<?php echo trans('deleted-successfully'); ?>">
<input type="hidden" class="msg_data_limit_over" value="<?php echo trans('data-limit-over'); ?>">
<input type="hidden" class="msg_email_exist" value="<?php echo trans('email-exist'); ?>">
<input type="hidden" class="msg_recaptcha_is_required" value="<?php echo trans('recaptcha-is-required'); ?>">


<input type="hidden" class="msg_not_active" value="<?php echo trans('account-not-active'); ?>">
<input type="hidden" class="msg_signin" value="<?php echo trans('sign-in'); ?>">
<input type="hidden" class="msg_signing_in" value="<?php echo trans('signing-in'); ?>">

<input type="hidden" class="msg_wrong_access" value="<?php echo trans('wrong-username-password'); ?>">
<input type="hidden" class="msg_email_not_verified" value="<?php echo trans('email-not-verified'); ?>">
<input type="hidden" class="msg_pass_sent_email" value="<?php echo trans('password-sent-to-email'); ?>">
<input type="hidden" class="msg_pass_reset_succ" value="<?php echo trans('password-reset-successfully'); ?>">
<input type="hidden" class="msg_not_valid_user" value="<?php echo trans('not-a-valid-user'); ?>">
